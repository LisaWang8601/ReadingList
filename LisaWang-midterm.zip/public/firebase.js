export default {
    apiKey: "AIzaSyCvTaQvKt_lTylJkl28dUVu-pBQkQu_97M",
    authDomain: "todoapp-lw.firebaseapp.com",
    databaseURL: "https://todoapp-lw.firebaseio.com",
    projectId: "todoapp-lw",
    storageBucket: "todoapp-lw.appspot.com",
    messagingSenderId: "287931869906"
};